import React from 'react'
import { Trophy, Target, Heart, Globe, Users, Award } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'

const About = () => {
  const objectives = [
    {
      icon: Trophy,
      title: 'تكريم الجماهير',
      description: 'الاحتفاء بالجماهير الرياضية وتقدير دورهم المهم في دعم الرياضة'
    },
    {
      icon: Globe,
      title: 'التواصل العالمي',
      description: 'ربط الجماهير الرياضية من جميع أنحاء العالم في منصة واحدة'
    },
    {
      icon: Heart,
      title: 'نشر الشغف',
      description: 'تعزيز حب الرياضة والشغف الرياضي بين الأجيال'
    },
    {
      icon: Users,
      title: 'بناء المجتمع',
      description: 'إنشاء مجتمع رياضي متماسك يجمع المشجعين من كل مكان'
    }
  ]

  const values = [
    'الشغف والحماس الرياضي',
    'التنوع والشمولية',
    'الروح الرياضية النبيلة',
    'التقدير والاحترام المتبادل',
    'الإبداع في التشجيع',
    'الوحدة عبر الرياضة'
  ]

  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="py-20 sports-gradient">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
            عن المسابقة
          </h1>
          <p className="text-xl text-white opacity-90 max-w-3xl mx-auto leading-relaxed">
            مبادرة عالمية تهدف إلى تكريم الجماهير الرياضية وإبراز دورهم المحوري في دعم الرياضة والرياضيين
          </p>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl font-bold sports-text-dark mb-6 section-title">
                رسالتنا
              </h2>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                نؤمن بأن الجماهير الرياضية هم القلب النابض للرياضة. هم من يخلقون الأجواء الحماسية، 
                ويدعمون الرياضيين في أصعب اللحظات، ويجعلون من كل مباراة حدثاً لا يُنسى.
              </p>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                مسابقة الجماهير الرياضية العالمية هي منصة للاحتفاء بهذا الشغف والتفاني، 
                وتقدير الجماهير الذين يسافرون آلاف الأميال، ويقضون ساعات في التشجيع، 
                ويبدعون في إظهار حبهم لفرقهم ورياضييهم المفضلين.
              </p>
              <div className="flex items-center space-x-4 rtl:space-x-reverse">
                <div className="w-16 h-16 sports-bg-green rounded-full flex items-center justify-center">
                  <Heart className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold sports-text-dark">الشغف أولاً</h3>
                  <p className="text-gray-600">نحتفي بالحب الحقيقي للرياضة</p>
                </div>
              </div>
            </div>
            <div className="relative">
              <img 
                src="/src/assets/images/fans/fans_2.jpg" 
                alt="جماهير رياضية متحمسة" 
                className="rounded-2xl shadow-2xl w-full h-96 object-cover"
              />
              <div className="absolute -top-6 -left-6 w-full h-full sports-bg-blue rounded-2xl opacity-20"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Objectives Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold sports-text-dark mb-4 section-title">
              أهدافنا
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              نسعى لتحقيق مجموعة من الأهداف النبيلة التي تخدم المجتمع الرياضي العالمي
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {objectives.map((objective, index) => {
              const Icon = objective.icon
              return (
                <Card key={index} className="card-hover border-0 shadow-lg">
                  <CardContent className="p-8 text-center">
                    <div className="w-16 h-16 sports-bg-blue rounded-full flex items-center justify-center mx-auto mb-6">
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-xl font-bold sports-text-dark mb-4">{objective.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{objective.description}</p>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold sports-text-dark mb-4 section-title">
              قيمنا
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              المبادئ والقيم التي نؤمن بها وتوجه عملنا في هذه المسابقة العالمية
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {values.map((value, index) => (
              <div key={index} className="flex items-center space-x-4 rtl:space-x-reverse p-6 bg-gray-50 rounded-xl hover:shadow-lg transition-all duration-300">
                <div className="w-12 h-12 sports-bg-gold rounded-full flex items-center justify-center flex-shrink-0">
                  <Award className="w-6 h-6 text-white" />
                </div>
                <span className="text-lg font-medium sports-text-dark">{value}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Sponsor Section */}
      <section className="py-20 sports-gradient">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            الراعي الرسمي
          </h2>
          <p className="text-xl text-white opacity-90 mb-12 max-w-3xl mx-auto leading-relaxed">
            نفخر بشراكتنا مع مجموعة شركات الدكتور سليمان بن حمد الصنيع وأولاده، 
            الراعي الرسمي لهذه المبادرة العالمية المميزة
          </p>
          
          <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-2xl p-12 max-w-4xl mx-auto">
            <div className="flex justify-center mb-8">
              <img 
                src="/src/assets/images/sponsor/sponsor_logo.png" 
                alt="مجموعة شركات الدكتور سليمان بن حمد الصنيع وأولاده" 
                className="h-20 opacity-90"
              />
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">
              مجموعة شركات الدكتور سليمان بن حمد الصنيع وأولاده
            </h3>
            <p className="text-lg text-white opacity-90 leading-relaxed">
              مجموعة رائدة تؤمن بأهمية دعم المبادرات الرياضية والثقافية التي تخدم المجتمع. 
              من خلال رعايتها لهذه المسابقة، تؤكد المجموعة التزامها بتعزيز الروح الرياضية 
              والاحتفاء بالجماهير الرياضية حول العالم.
            </p>
          </div>
        </div>
      </section>

      {/* History Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold sports-text-dark mb-4 section-title">
              تاريخ المبادرة
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              رحلة المسابقة من الفكرة إلى الحدث العالمي
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="space-y-8">
              <div className="flex items-start space-x-6 rtl:space-x-reverse">
                <div className="w-16 h-16 sports-bg-green rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-white font-bold">2024</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold sports-text-dark mb-2">انطلاق المبادرة</h3>
                  <p className="text-gray-600 leading-relaxed">
                    بدأت فكرة المسابقة من رغبة حقيقية في تكريم الجماهير الرياضية وإبراز دورهم المهم. 
                    تم تطوير المفهوم وإعداد الخطط الأولية للمسابقة العالمية.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-6 rtl:space-x-reverse">
                <div className="w-16 h-16 sports-bg-blue rounded-full flex items-center justify-center flex-shrink-0">
                  <Trophy className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold sports-text-dark mb-2">التطوير والإعداد</h3>
                  <p className="text-gray-600 leading-relaxed">
                    تم تطوير منصة المسابقة الرقمية وإعداد معايير التقييم والجوائز. 
                    كما تم تأسيس الشراكات مع الرعاة والمؤسسات الرياضية المختلفة.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-6 rtl:space-x-reverse">
                <div className="w-16 h-16 sports-bg-gold rounded-full flex items-center justify-center flex-shrink-0">
                  <Globe className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold sports-text-dark mb-2">الإطلاق العالمي</h3>
                  <p className="text-gray-600 leading-relaxed">
                    إطلاق المسابقة رسمياً على المستوى العالمي مع مشاركة متوقعة من أكثر من 50 دولة 
                    وتغطية لأكثر من 15 رياضة مختلفة.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default About

