import React from 'react'

const Contact = () => {
  return (
    <div className="min-h-screen pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <h1 className="text-4xl font-bold text-center mb-8">التواصل والدعم</h1>
        <p className="text-xl text-center text-gray-600 mb-16">قريباً...</p>
      </div>
    </div>
  )
}

export default Contact

