import React, { useState } from 'react'
import { 
  User, 
  Trophy, 
  Eye, 
  Heart, 
  Share2, 
  MessageCircle, 
  TrendingUp, 
  Users, 
  Mail, 
  Phone, 
  Copy,
  CheckCircle,
  Clock,
  Star,
  Award,
  BarChart3,
  Calendar,
  Download
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'

const ParticipantDashboard = () => {
  const [inviteMethod, setInviteMethod] = useState('link')
  const [copied, setCopied] = useState(false)

  // بيانات المشارك الوهمية
  const participantData = {
    name: 'أحمد محمد',
    email: 'ahmed.mohamed@email.com',
    country: 'مصر',
    sport: 'كرة القدم',
    registrationDate: '2024-01-15',
    status: 'approved',
    submission: {
      id: 'SUB-2024-001',
      title: 'جماهير الأهلي في نهائي دوري الأبطال',
      description: 'لحظة تاريخية من جماهير النادي الأهلي في نهائي دوري أبطال أفريقيا',
      image: '/src/assets/images/fans/fans_1.jpg',
      votes: 1250,
      views: 5420,
      comments: 89,
      shares: 156,
      rank: 1,
      percentage: 18.5,
      trend: '+250'
    }
  }

  const stats = [
    { label: 'الأصوات', value: participantData.submission.votes, icon: Heart, color: 'text-red-500', trend: '+12%' },
    { label: 'المشاهدات', value: participantData.submission.views, icon: Eye, color: 'text-blue-500', trend: '+8%' },
    { label: 'التعليقات', value: participantData.submission.comments, icon: MessageCircle, color: 'text-green-500', trend: '+15%' },
    { label: 'المشاركات', value: participantData.submission.shares, icon: Share2, color: 'text-purple-500', trend: '+22%' }
  ]

  const inviteStats = [
    { method: 'رابط المشاركة', count: 45, conversions: 12 },
    { method: 'البريد الإلكتروني', count: 23, conversions: 8 },
    { method: 'وسائل التواصل', count: 67, conversions: 18 }
  ]

  const recentActivity = [
    { type: 'vote', user: 'سارة أحمد', time: 'منذ 5 دقائق', action: 'صوتت لمشاركتك' },
    { type: 'comment', user: 'محمد علي', time: 'منذ 15 دقيقة', action: 'علق على مشاركتك' },
    { type: 'share', user: 'فاطمة الزهراء', time: 'منذ 30 دقيقة', action: 'شاركت مشاركتك' },
    { type: 'view', user: 'أحمد خالد', time: 'منذ ساعة', action: 'شاهد مشاركتك' }
  ]

  const handleCopyLink = () => {
    const link = `https://sports-competition.com/vote/${participantData.submission.id}`
    navigator.clipboard.writeText(link)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const getStatusBadge = (status) => {
    switch(status) {
      case 'approved':
        return <Badge className="bg-green-100 text-green-800">مقبولة</Badge>
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800">قيد المراجعة</Badge>
      case 'rejected':
        return <Badge className="bg-red-100 text-red-800">مرفوضة</Badge>
      default:
        return <Badge variant="secondary">غير محدد</Badge>
    }
  }

  const getActivityIcon = (type) => {
    switch(type) {
      case 'vote': return <Heart className="w-4 h-4 text-red-500" />
      case 'comment': return <MessageCircle className="w-4 h-4 text-green-500" />
      case 'share': return <Share2 className="w-4 h-4 text-purple-500" />
      case 'view': return <Eye className="w-4 h-4 text-blue-500" />
      default: return <Star className="w-4 h-4 text-gray-500" />
    }
  }

  return (
    <div className="min-h-screen pt-16 bg-gray-50">
      {/* Header */}
      <section className="py-12 sports-gradient">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="text-white mb-6 md:mb-0">
              <h1 className="text-4xl font-bold mb-2">مرحباً، {participantData.name}</h1>
              <p className="text-xl opacity-90">لوحة تحكم المشارك</p>
            </div>
            <div className="flex items-center space-x-4 rtl:space-x-reverse">
              <div className="text-center">
                <div className="text-3xl font-bold text-white">#{participantData.submission.rank}</div>
                <div className="text-white opacity-90 text-sm">المركز الحالي</div>
              </div>
              <div className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                <Trophy className="w-8 h-8 text-yellow-300" />
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="overview" className="space-y-8">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
            <TabsTrigger value="submission">مشاركتي</TabsTrigger>
            <TabsTrigger value="invite">دعوة الأصدقاء</TabsTrigger>
            <TabsTrigger value="analytics">الإحصائيات</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-8">
            {/* Stats Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {stats.map((stat, index) => {
                const Icon = stat.icon
                return (
                  <Card key={index} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <Icon className={`w-8 h-8 ${stat.color}`} />
                        <Badge variant="outline" className="text-green-600 border-green-200">
                          {stat.trend}
                        </Badge>
                      </div>
                      <div className="text-2xl font-bold sports-text-dark mb-1">
                        {stat.value.toLocaleString()}
                      </div>
                      <div className="text-sm text-gray-600">{stat.label}</div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>

            {/* Submission Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <CheckCircle className="w-5 h-5 ml-2 text-green-500" />
                  حالة المشاركة
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold sports-text-dark">
                      {participantData.submission.title}
                    </h3>
                    <p className="text-gray-600">رقم المشاركة: {participantData.submission.id}</p>
                  </div>
                  {getStatusBadge(participantData.status)}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <div className="text-2xl font-bold sports-text-dark">{participantData.submission.percentage}%</div>
                    <div className="text-sm text-gray-600">من إجمالي الأصوات</div>
                  </div>
                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <div className="text-2xl font-bold sports-text-dark">#{participantData.submission.rank}</div>
                    <div className="text-sm text-gray-600">الترتيب الحالي</div>
                  </div>
                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <div className="text-2xl font-bold sports-text-dark">{participantData.submission.trend}</div>
                    <div className="text-sm text-gray-600">أصوات اليوم</div>
                  </div>
                </div>

                <Progress value={participantData.submission.percentage * 5} className="h-3" />
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="w-5 h-5 ml-2" />
                  النشاط الأخير
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentActivity.map((activity, index) => (
                    <div key={index} className="flex items-center space-x-4 rtl:space-x-reverse p-3 bg-gray-50 rounded-lg">
                      {getActivityIcon(activity.type)}
                      <div className="flex-1">
                        <p className="text-sm">
                          <span className="font-medium">{activity.user}</span> {activity.action}
                        </p>
                        <p className="text-xs text-gray-500">{activity.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Submission Tab */}
          <TabsContent value="submission" className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle>تفاصيل المشاركة</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div>
                    <img 
                      src={participantData.submission.image} 
                      alt={participantData.submission.title}
                      className="w-full h-64 object-cover rounded-lg mb-4"
                    />
                    <div className="flex items-center justify-between text-sm text-gray-500">
                      <span className="flex items-center">
                        <Eye className="w-4 h-4 ml-1" />
                        {participantData.submission.views.toLocaleString()} مشاهدة
                      </span>
                      <span className="flex items-center">
                        <Heart className="w-4 h-4 ml-1" />
                        {participantData.submission.votes.toLocaleString()} صوت
                      </span>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-xl font-bold sports-text-dark mb-4">
                      {participantData.submission.title}
                    </h3>
                    <p className="text-gray-600 mb-6 leading-relaxed">
                      {participantData.submission.description}
                    </p>
                    
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <span className="text-gray-600">الرياضة:</span>
                        <Badge variant="outline">{participantData.sport}</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">الدولة:</span>
                        <span className="font-medium">{participantData.country}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">تاريخ التسجيل:</span>
                        <span className="font-medium">{participantData.registrationDate}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Invite Tab */}
          <TabsContent value="invite" className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="w-5 h-5 ml-2" />
                  ادع أصدقاءك للتصويت
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-6">
                  شارك مشاركتك مع الأصدقاء والعائلة لزيادة فرصك في الفوز
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div>
                    <h3 className="text-lg font-semibold mb-4">مشاركة الرابط</h3>
                    <div className="flex items-center space-x-2 rtl:space-x-reverse mb-4">
                      <input 
                        type="text" 
                        value={`https://sports-competition.com/vote/${participantData.submission.id}`}
                        readOnly
                        className="flex-1 p-3 border rounded-lg bg-gray-50"
                      />
                      <Button onClick={handleCopyLink} variant="outline">
                        {copied ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                      </Button>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-3">
                      <Button variant="outline" className="flex items-center justify-center p-3">
                        <Mail className="w-4 h-4 ml-1" />
                        بريد
                      </Button>
                      <Button variant="outline" className="flex items-center justify-center p-3">
                        <Phone className="w-4 h-4 ml-1" />
                        واتساب
                      </Button>
                      <Button variant="outline" className="flex items-center justify-center p-3">
                        <Share2 className="w-4 h-4 ml-1" />
                        تويتر
                      </Button>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-4">إحصائيات الدعوات</h3>
                    <div className="space-y-4">
                      {inviteStats.map((stat, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div>
                            <div className="font-medium">{stat.method}</div>
                            <div className="text-sm text-gray-600">{stat.count} دعوة</div>
                          </div>
                          <div className="text-center">
                            <div className="text-lg font-bold sports-text-green">{stat.conversions}</div>
                            <div className="text-xs text-gray-500">صوت</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BarChart3 className="w-5 h-5 ml-2" />
                    تطور الأصوات
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
                    <div className="text-center">
                      <TrendingUp className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">رسم بياني لتطور الأصوات</p>
                      <p className="text-sm text-gray-500">سيتم عرض البيانات قريباً</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Calendar className="w-5 h-5 ml-2" />
                    النشاط اليومي
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">اليوم</span>
                      <div className="flex items-center space-x-2 rtl:space-x-reverse">
                        <span className="font-bold">+47</span>
                        <Badge variant="outline" className="text-green-600">+12%</Badge>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">أمس</span>
                      <div className="flex items-center space-x-2 rtl:space-x-reverse">
                        <span className="font-bold">+42</span>
                        <Badge variant="outline" className="text-green-600">+8%</Badge>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">هذا الأسبوع</span>
                      <div className="flex items-center space-x-2 rtl:space-x-reverse">
                        <span className="font-bold">+312</span>
                        <Badge variant="outline" className="text-green-600">+15%</Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>تقرير مفصل</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold mb-2">تحميل التقرير الشامل</h3>
                    <p className="text-gray-600">احصل على تقرير مفصل عن أداء مشاركتك</p>
                  </div>
                  <Button className="sports-bg-blue text-white">
                    <Download className="w-4 h-4 ml-2" />
                    تحميل PDF
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default ParticipantDashboard

