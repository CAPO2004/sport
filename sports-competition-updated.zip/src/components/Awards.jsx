import React from 'react'
import { Trophy, Award, Medal, Crown, Star, Gift, Users, Calendar } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

const Awards = () => {
  const mainAwards = [
    {
      title: 'الجائزة الكبرى',
      subtitle: 'أفضل جماهير رياضية عالمياً',
      prize: '100,000 ريال سعودي',
      icon: Crown,
      color: 'sports-bg-gold',
      description: 'للمشارك الذي يقدم أفضل محتوى يعبر عن الشغف والحماس الرياضي',
      benefits: [
        'جائزة نقدية 100,000 ريال',
        'رحلة مدفوعة التكاليف لحضور حدث رياضي عالمي',
        'شهادة تقدير موقعة',
        'تغطية إعلامية خاصة'
      ]
    },
    {
      title: 'جائزة أفضل محتوى مرئي',
      subtitle: 'للصور والفيديوهات المميزة',
      prize: '50,000 ريال سعودي',
      icon: Trophy,
      color: 'sports-bg-blue',
      description: 'للمحتوى المرئي الأكثر إبداعاً وتأثيراً في التشجيع',
      benefits: [
        'جائزة نقدية 50,000 ريال',
        'معدات تصوير احترافية',
        'ورشة تدريبية في التصوير الرياضي',
        'نشر المحتوى في المنصات الرسمية'
      ]
    },
    {
      title: 'جائزة أفضل قصة تشجيع',
      subtitle: 'للقصص الملهمة والمؤثرة',
      prize: '30,000 ريال سعودي',
      icon: Award,
      color: 'sports-bg-green',
      description: 'للقصة الأكثر إلهاماً وتأثيراً في عالم التشجيع الرياضي',
      benefits: [
        'جائزة نقدية 30,000 ريال',
        'نشر القصة في كتاب خاص',
        'مقابلة إعلامية مع وسائل الإعلام',
        'دعوة لحضور فعاليات رياضية'
      ]
    }
  ]

  const categoryAwards = [
    {
      category: 'كرة القدم',
      prize: '25,000 ريال',
      icon: Trophy,
      participants: '2,500+'
    },
    {
      category: 'كرة السلة',
      prize: '20,000 ريال',
      icon: Medal,
      participants: '1,800+'
    },
    {
      category: 'الكرة الطائرة',
      prize: '15,000 ريال',
      icon: Award,
      participants: '1,200+'
    },
    {
      category: 'السباحة',
      prize: '15,000 ريال',
      icon: Star,
      participants: '900+'
    },
    {
      category: 'ألعاب القوى',
      prize: '15,000 ريال',
      icon: Trophy,
      participants: '1,100+'
    },
    {
      category: 'الرياضات الإلكترونية',
      prize: '20,000 ريال',
      icon: Award,
      participants: '2,200+'
    }
  ]

  const specialAwards = [
    {
      title: 'جائزة الجماهير المتميزة',
      description: 'للمجموعات التي تظهر روح الفريق الاستثنائية',
      icon: Users,
      prize: '40,000 ريال'
    },
    {
      title: 'جائزة أصغر مشجع',
      description: 'للمشاركين تحت سن 16 عام',
      icon: Star,
      prize: '15,000 ريال'
    },
    {
      title: 'جائزة الإبداع في التشجيع',
      description: 'للأفكار الأكثر إبداعاً في التشجيع',
      icon: Gift,
      prize: '25,000 ريال'
    },
    {
      title: 'جائزة التأثير الاجتماعي',
      description: 'للمحتوى الذي يحمل رسالة اجتماعية إيجابية',
      icon: Award,
      prize: '20,000 ريال'
    }
  ]

  const evaluationCriteria = [
    {
      title: 'الإبداع والأصالة',
      percentage: '30%',
      description: 'مدى إبداع وأصالة المحتوى المقدم'
    },
    {
      title: 'التأثير العاطفي',
      percentage: '25%',
      description: 'قدرة المحتوى على إثارة المشاعر والحماس'
    },
    {
      title: 'جودة الإنتاج',
      percentage: '20%',
      description: 'الجودة التقنية للصور أو الفيديوهات'
    },
    {
      title: 'القصة والسرد',
      percentage: '15%',
      description: 'قوة القصة وطريقة السرد'
    },
    {
      title: 'التفاعل الجماهيري',
      percentage: '10%',
      description: 'مستوى التفاعل والإعجاب من الجمهور'
    }
  ]

  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="py-20 sports-gradient">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
            الجوائز والتكريم
          </h1>
          <p className="text-xl text-white opacity-90 max-w-3xl mx-auto leading-relaxed">
            جوائز قيمة وتكريم استثنائي للجماهير الرياضية المميزة حول العالم
          </p>
        </div>
      </section>

      {/* Main Awards Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold sports-text-dark mb-4 section-title">
              الجوائز الرئيسية
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              جوائز استثنائية للمشاركات المتميزة في المسابقة العالمية
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {mainAwards.map((award, index) => {
              const Icon = award.icon
              return (
                <Card key={index} className="card-hover border-0 shadow-2xl relative overflow-hidden">
                  <div className={`absolute top-0 left-0 right-0 h-2 ${award.color}`}></div>
                  <CardContent className="p-8 text-center">
                    <div className={`w-20 h-20 ${award.color} rounded-full flex items-center justify-center mx-auto mb-6`}>
                      <Icon className="w-10 h-10 text-white" />
                    </div>
                    <h3 className="text-2xl font-bold sports-text-dark mb-2">{award.title}</h3>
                    <p className="text-lg text-gray-600 mb-4">{award.subtitle}</p>
                    <div className="text-3xl font-bold sports-text-gold mb-6">{award.prize}</div>
                    <p className="text-gray-600 mb-8 leading-relaxed">{award.description}</p>
                    
                    <div className="space-y-3 mb-8">
                      {award.benefits.map((benefit, idx) => (
                        <div key={idx} className="flex items-center space-x-3 rtl:space-x-reverse">
                          <div className="w-6 h-6 sports-bg-green rounded-full flex items-center justify-center flex-shrink-0">
                            <Star className="w-3 h-3 text-white" />
                          </div>
                          <span className="text-sm text-gray-600">{benefit}</span>
                        </div>
                      ))}
                    </div>
                    
                    <Button className="w-full sports-bg-green hover:bg-green-600 text-white">
                      تفاصيل أكثر
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Category Awards */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold sports-text-dark mb-4 section-title">
              جوائز الرياضات
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              جوائز مخصصة لكل رياضة على حدة لتكريم أفضل الجماهير
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {categoryAwards.map((award, index) => {
              const Icon = award.icon
              return (
                <Card key={index} className="card-hover border-0 shadow-lg">
                  <CardContent className="p-8 text-center">
                    <div className="w-16 h-16 sports-bg-blue rounded-full flex items-center justify-center mx-auto mb-6">
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-xl font-bold sports-text-dark mb-4">{award.category}</h3>
                    <div className="text-2xl font-bold sports-text-gold mb-4">{award.prize}</div>
                    <div className="text-sm text-gray-500 mb-4">
                      <Users className="w-4 h-4 inline mr-2" />
                      {award.participants} مشارك
                    </div>
                    <Button variant="outline" className="w-full border-blue-500 text-blue-600 hover:bg-blue-50">
                      عرض المشاركات
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Special Awards */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold sports-text-dark mb-4 section-title">
              الجوائز الخاصة
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              جوائز إضافية لتكريم الفئات والمواهب المميزة
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {specialAwards.map((award, index) => {
              const Icon = award.icon
              return (
                <Card key={index} className="card-hover border-0 shadow-lg">
                  <CardContent className="p-8">
                    <div className="flex items-start space-x-4 rtl:space-x-reverse">
                      <div className="w-16 h-16 sports-bg-gold rounded-full flex items-center justify-center flex-shrink-0">
                        <Icon className="w-8 h-8 text-white" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-xl font-bold sports-text-dark mb-2">{award.title}</h3>
                        <p className="text-gray-600 mb-4 leading-relaxed">{award.description}</p>
                        <div className="text-2xl font-bold sports-text-gold">{award.prize}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Evaluation Criteria */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold sports-text-dark mb-4 section-title">
              معايير التقييم
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              المعايير التي يتم على أساسها تقييم المشاركات واختيار الفائزين
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="space-y-6">
              {evaluationCriteria.map((criteria, index) => (
                <Card key={index} className="border-0 shadow-lg">
                  <CardContent className="p-8">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-xl font-bold sports-text-dark">{criteria.title}</h3>
                      <div className="text-2xl font-bold sports-text-green">{criteria.percentage}</div>
                    </div>
                    <p className="text-gray-600 leading-relaxed">{criteria.description}</p>
                    <div className="mt-4 bg-gray-200 rounded-full h-2">
                      <div 
                        className="sports-bg-green h-2 rounded-full transition-all duration-1000"
                        style={{ width: criteria.percentage }}
                      ></div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Award Ceremony */}
      <section className="py-20 sports-gradient">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            حفل التكريم
          </h2>
          <p className="text-xl text-white opacity-90 mb-8 max-w-3xl mx-auto leading-relaxed">
            حفل مميز لتكريم الفائزين وتسليم الجوائز بحضور شخصيات رياضية وإعلامية بارزة
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-2xl p-8">
              <Calendar className="w-12 h-12 text-white mx-auto mb-4" />
              <h3 className="text-xl font-bold text-white mb-2">التاريخ</h3>
              <p className="text-white opacity-90">ديسمبر 2024</p>
            </div>
            <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-2xl p-8">
              <Trophy className="w-12 h-12 text-white mx-auto mb-4" />
              <h3 className="text-xl font-bold text-white mb-2">الجوائز</h3>
              <p className="text-white opacity-90">أكثر من 100 جائزة</p>
            </div>
            <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-2xl p-8">
              <Users className="w-12 h-12 text-white mx-auto mb-4" />
              <h3 className="text-xl font-bold text-white mb-2">الحضور</h3>
              <p className="text-white opacity-90">500+ مدعو</p>
            </div>
          </div>
          
          <Button className="bg-white text-black hover:bg-gray-100 px-8 py-3 rounded-full text-lg font-bold">
            احجز مقعدك
          </Button>
        </div>
      </section>

      {/* Prize Pool */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold sports-text-dark mb-6 section-title">
            إجمالي قيمة الجوائز
          </h2>
          <div className="text-6xl md:text-8xl font-bold sports-text-gold mb-8">
            500,000 ريال
          </div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            نصف مليون ريال سعودي موزعة على أكثر من 100 جائزة قيمة لتكريم أفضل الجماهير الرياضية
          </p>
        </div>
      </section>
    </div>
  )
}

export default Awards

