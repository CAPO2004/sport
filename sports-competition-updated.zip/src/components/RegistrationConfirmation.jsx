import React, { useState, useEffect } from 'react'
import { CheckCircle, Mail, Phone, Clock, User, Trophy, ArrowRight, Share2, Calendar } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

const RegistrationConfirmation = () => {
  const [confirmationSent, setConfirmationSent] = useState(false)
  const [timeLeft, setTimeLeft] = useState({
    days: 45,
    hours: 12,
    minutes: 30,
    seconds: 15
  })

  useEffect(() => {
    // محاكاة إرسال رسالة التأكيد
    const timer = setTimeout(() => {
      setConfirmationSent(true)
    }, 2000)

    return () => clearTimeout(timer)
  }, [])

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 }
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 }
        } else if (prev.hours > 0) {
          return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 }
        } else if (prev.days > 0) {
          return { ...prev, days: prev.days - 1, hours: 23, minutes: 59, seconds: 59 }
        }
        return prev
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  // بيانات التسجيل الوهمية
  const registrationData = {
    id: 'REG-2024-001',
    name: 'أحمد محمد',
    email: 'ahmed.mohamed@email.com',
    country: 'مصر',
    sport: 'كرة القدم',
    submissionTitle: 'جماهير الأهلي في نهائي دوري الأبطال',
    registrationDate: new Date().toLocaleDateString('ar-EG'),
    status: 'pending_review'
  }

  const nextSteps = [
    {
      step: 1,
      title: 'مراجعة المشاركة',
      description: 'سيقوم فريقنا بمراجعة مشاركتك خلال 24-48 ساعة',
      status: 'current',
      estimatedTime: '1-2 أيام'
    },
    {
      step: 2,
      title: 'الموافقة والنشر',
      description: 'بعد الموافقة، ستظهر مشاركتك في المعرض للتصويت',
      status: 'upcoming',
      estimatedTime: '3-5 أيام'
    },
    {
      step: 3,
      title: 'بداية التصويت',
      description: 'يمكن للجمهور التصويت لمشاركتك',
      status: 'upcoming',
      estimatedTime: '1 أسبوع'
    },
    {
      step: 4,
      title: 'إعلان النتائج',
      description: 'سيتم إعلان النتائج النهائية والفائزين',
      status: 'upcoming',
      estimatedTime: '45 يوم'
    }
  ]

  const benefits = [
    {
      icon: Trophy,
      title: 'فرصة للفوز',
      description: 'إمكانية الفوز بجوائز قيمة وتكريم عالمي'
    },
    {
      icon: Share2,
      title: 'انتشار واسع',
      description: 'عرض مشاركتك أمام جمهور عالمي كبير'
    },
    {
      icon: User,
      title: 'تقدير الشغف',
      description: 'تكريم حبك وشغفك بالرياضة'
    }
  ]

  const getStatusColor = (status) => {
    switch(status) {
      case 'current': return 'bg-blue-500'
      case 'completed': return 'bg-green-500'
      case 'upcoming': return 'bg-gray-300'
      default: return 'bg-gray-300'
    }
  }

  return (
    <div className="min-h-screen pt-16 bg-gray-50">
      {/* Success Header */}
      <section className="py-20 sports-gradient">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="mb-8">
            <div className="w-24 h-24 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-12 h-12 text-white" />
            </div>
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              تم التسجيل بنجاح!
            </h1>
            <p className="text-xl text-white opacity-90 max-w-2xl mx-auto leading-relaxed">
              شكراً لك على المشاركة في مسابقة الجماهير الرياضية العالمية
            </p>
          </div>

          {/* Registration ID */}
          <div className="bg-white bg-opacity-20 rounded-2xl p-6 backdrop-blur-sm">
            <h3 className="text-lg font-bold text-white mb-2">رقم التسجيل</h3>
            <div className="text-3xl font-bold text-yellow-300">{registrationData.id}</div>
            <p className="text-white opacity-90 text-sm mt-2">احتفظ بهذا الرقم للمراجعة</p>
          </div>
        </div>
      </section>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Confirmation Status */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Mail className="w-5 h-5 ml-2 text-blue-500" />
                تأكيد البريد الإلكتروني
              </CardTitle>
            </CardHeader>
            <CardContent>
              {confirmationSent ? (
                <div className="flex items-center space-x-3 rtl:space-x-reverse text-green-600">
                  <CheckCircle className="w-5 h-5" />
                  <span>تم إرسال رسالة التأكيد إلى {registrationData.email}</span>
                </div>
              ) : (
                <div className="flex items-center space-x-3 rtl:space-x-reverse text-blue-600">
                  <Clock className="w-5 h-5 animate-spin" />
                  <span>جاري إرسال رسالة التأكيد...</span>
                </div>
              )}
              <p className="text-sm text-gray-600 mt-3">
                تحقق من صندوق الوارد وملف الرسائل غير المرغوب فيها
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Phone className="w-5 h-5 ml-2 text-green-500" />
                تأكيد الرسائل النصية
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-3 rtl:space-x-reverse text-green-600">
                <CheckCircle className="w-5 h-5" />
                <span>سيتم إرسال تحديثات عبر الرسائل النصية</span>
              </div>
              <p className="text-sm text-gray-600 mt-3">
                ستتلقى إشعارات مهمة حول حالة مشاركتك
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Registration Summary */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle>ملخص التسجيل</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-gray-600">الاسم:</span>
                  <span className="font-medium">{registrationData.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">البريد الإلكتروني:</span>
                  <span className="font-medium">{registrationData.email}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">الدولة:</span>
                  <span className="font-medium">{registrationData.country}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">الرياضة:</span>
                  <Badge variant="outline">{registrationData.sport}</Badge>
                </div>
              </div>
              
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-gray-600">عنوان المشاركة:</span>
                  <span className="font-medium text-right max-w-48">{registrationData.submissionTitle}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">تاريخ التسجيل:</span>
                  <span className="font-medium">{registrationData.registrationDate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">الحالة:</span>
                  <Badge className="bg-yellow-100 text-yellow-800">قيد المراجعة</Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Next Steps */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle>الخطوات التالية</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {nextSteps.map((step, index) => (
                <div key={index} className="flex items-start space-x-4 rtl:space-x-reverse">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold ${getStatusColor(step.status)}`}>
                    {step.step}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-lg font-semibold sports-text-dark">{step.title}</h3>
                      <Badge variant="outline" className="text-xs">
                        {step.estimatedTime}
                      </Badge>
                    </div>
                    <p className="text-gray-600">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Countdown Timer */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Calendar className="w-5 h-5 ml-2" />
              العد التنازلي لإعلان النتائج
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-4 gap-4 mb-6">
              {Object.entries(timeLeft).map(([unit, value]) => (
                <div key={unit} className="text-center p-4 bg-gray-50 rounded-lg">
                  <div className="text-3xl font-bold sports-text-dark mb-2">{value}</div>
                  <div className="text-sm text-gray-600">
                    {unit === 'days' ? 'يوم' : 
                     unit === 'hours' ? 'ساعة' : 
                     unit === 'minutes' ? 'دقيقة' : 'ثانية'}
                  </div>
                </div>
              ))}
            </div>
            <p className="text-center text-gray-600">
              ستتلقى إشعاراً عند إعلان النتائج النهائية
            </p>
          </CardContent>
        </Card>

        {/* Benefits */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon
            return (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardContent className="p-8">
                  <div className="w-16 h-16 sports-bg-blue rounded-full flex items-center justify-center mx-auto mb-6">
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold sports-text-dark mb-4">{benefit.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{benefit.description}</p>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Action Buttons */}
        <div className="text-center space-y-4">
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="sports-bg-blue text-white px-8 py-3 rounded-full text-lg">
              انتقل إلى لوحة التحكم
              <ArrowRight className="w-5 h-5 mr-2" />
            </Button>
            <Button variant="outline" className="border-green-500 text-green-600 hover:bg-green-50 px-8 py-3 rounded-full text-lg">
              شاهد المعرض
            </Button>
          </div>
          
          <p className="text-sm text-gray-600 max-w-2xl mx-auto">
            يمكنك متابعة حالة مشاركتك وإحصائياتها من خلال لوحة التحكم الخاصة بك
          </p>
        </div>
      </div>
    </div>
  )
}

export default RegistrationConfirmation

