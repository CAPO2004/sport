import React, { useState, useEffect } from 'react'
import { Trophy, Medal, Star, TrendingUp, Users, Eye, Heart, Calendar, Award } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'

const Results = () => {
  const [activeTab, setActiveTab] = useState('overall')
  const [timeLeft, setTimeLeft] = useState({
    days: 15,
    hours: 8,
    minutes: 32,
    seconds: 45
  })

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 }
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 }
        } else if (prev.hours > 0) {
          return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 }
        } else if (prev.days > 0) {
          return { ...prev, days: prev.days - 1, hours: 23, minutes: 59, seconds: 59 }
        }
        return prev
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  // بيانات النتائج الوهمية
  const overallResults = [
    {
      rank: 1,
      title: 'جماهير الأهلي في نهائي دوري الأبطال',
      participant: 'أحمد محمد',
      country: 'مصر',
      sport: 'كرة القدم',
      votes: 15420,
      views: 45230,
      image: '/src/assets/images/fans/fans_1.jpg',
      trend: '+250',
      percentage: 18.5
    },
    {
      rank: 2,
      title: 'مشجعو المنتخب السعودي في كأس العالم',
      participant: 'سارة العتيبي',
      country: 'السعودية',
      sport: 'كرة القدم',
      votes: 12890,
      views: 38910,
      image: '/src/assets/images/fans/fans_2.jpg',
      trend: '+180',
      percentage: 15.2
    },
    {
      rank: 3,
      title: 'جماهير كرة السلة في الدوري الأمريكي',
      participant: 'محمد الأحمد',
      country: 'الإمارات',
      sport: 'كرة السلة',
      votes: 9750,
      views: 28450,
      image: '/src/assets/images/sports/sports_1.jpeg',
      trend: '+95',
      percentage: 11.8
    },
    {
      rank: 4,
      title: 'مشجعو التنس في بطولة ويمبلدون',
      participant: 'فاطمة الزهراء',
      country: 'المغرب',
      sport: 'التنس',
      votes: 7620,
      views: 22180,
      image: '/src/assets/images/sports/sports_2.jpg',
      trend: '+67',
      percentage: 9.1
    },
    {
      rank: 5,
      title: 'جماهير الكريكت في الهند',
      participant: 'راج باتيل',
      country: 'الهند',
      sport: 'الكريكت',
      votes: 6890,
      views: 19750,
      image: '/src/assets/images/sports/sports_1.jpeg',
      trend: '+45',
      percentage: 8.3
    }
  ]

  const categoryResults = {
    football: overallResults.filter(r => r.sport === 'كرة القدم'),
    basketball: overallResults.filter(r => r.sport === 'كرة السلة'),
    tennis: overallResults.filter(r => r.sport === 'التنس'),
    cricket: overallResults.filter(r => r.sport === 'الكريكت')
  }

  const stats = [
    { label: 'إجمالي الأصوات', value: '83,570', icon: Heart, color: 'text-red-500' },
    { label: 'إجمالي المشاهدات', value: '234,520', icon: Eye, color: 'text-blue-500' },
    { label: 'المشاركون', value: '1,247', icon: Users, color: 'text-green-500' },
    { label: 'الدول المشاركة', value: '67', icon: Award, color: 'text-purple-500' }
  ]

  const getRankIcon = (rank) => {
    switch(rank) {
      case 1: return <Trophy className="w-6 h-6 text-yellow-500" />
      case 2: return <Medal className="w-6 h-6 text-gray-400" />
      case 3: return <Medal className="w-6 h-6 text-amber-600" />
      default: return <Star className="w-6 h-6 text-blue-500" />
    }
  }

  const getRankBadgeColor = (rank) => {
    switch(rank) {
      case 1: return 'bg-gradient-to-r from-yellow-400 to-yellow-600 text-white'
      case 2: return 'bg-gradient-to-r from-gray-300 to-gray-500 text-white'
      case 3: return 'bg-gradient-to-r from-amber-400 to-amber-600 text-white'
      default: return 'bg-gradient-to-r from-blue-400 to-blue-600 text-white'
    }
  }

  const currentResults = activeTab === 'overall' ? overallResults : categoryResults[activeTab] || []

  return (
    <div className="min-h-screen pt-16 bg-gray-50">
      {/* Header Section */}
      <section className="sports-gradient py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
            النتائج والترتيب
          </h1>
          <p className="text-xl text-white opacity-90 mb-8 max-w-3xl mx-auto">
            تابع النتائج المباشرة للمسابقة وشاهد ترتيب المشاركات الأكثر تميزاً
          </p>

          {/* Countdown Timer */}
          <div className="max-w-2xl mx-auto mb-8">
            <h3 className="text-2xl font-bold text-white mb-6">العد التنازلي لإعلان النتائج النهائية</h3>
            <div className="grid grid-cols-4 gap-4">
              {Object.entries(timeLeft).map(([unit, value]) => (
                <div key={unit} className="bg-white bg-opacity-20 rounded-2xl p-4 text-center backdrop-blur-sm">
                  <div className="text-3xl md:text-4xl font-bold text-white mb-2">{value}</div>
                  <div className="text-sm text-gray-200">
                    {unit === 'days' ? 'يوم' : 
                     unit === 'hours' ? 'ساعة' : 
                     unit === 'minutes' ? 'دقيقة' : 'ثانية'}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, index) => {
              const Icon = stat.icon
              return (
                <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <Icon className={`w-8 h-8 ${stat.color} mx-auto mb-4`} />
                    <div className="text-3xl font-bold sports-text-dark mb-2">{stat.value}</div>
                    <div className="text-gray-600 text-sm">{stat.label}</div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Results Tabs */}
      <section className="py-8 bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap gap-4 justify-center">
            <Button
              variant={activeTab === 'overall' ? "default" : "outline"}
              onClick={() => setActiveTab('overall')}
              className={`rounded-full px-6 py-2 ${
                activeTab === 'overall' 
                  ? 'sports-bg-blue text-white' 
                  : 'border-gray-300 text-gray-700 hover:border-blue-500'
              }`}
            >
              الترتيب العام
            </Button>
            <Button
              variant={activeTab === 'football' ? "default" : "outline"}
              onClick={() => setActiveTab('football')}
              className={`rounded-full px-6 py-2 ${
                activeTab === 'football' 
                  ? 'sports-bg-blue text-white' 
                  : 'border-gray-300 text-gray-700 hover:border-blue-500'
              }`}
            >
              كرة القدم
            </Button>
            <Button
              variant={activeTab === 'basketball' ? "default" : "outline"}
              onClick={() => setActiveTab('basketball')}
              className={`rounded-full px-6 py-2 ${
                activeTab === 'basketball' 
                  ? 'sports-bg-blue text-white' 
                  : 'border-gray-300 text-gray-700 hover:border-blue-500'
              }`}
            >
              كرة السلة
            </Button>
            <Button
              variant={activeTab === 'tennis' ? "default" : "outline"}
              onClick={() => setActiveTab('tennis')}
              className={`rounded-full px-6 py-2 ${
                activeTab === 'tennis' 
                  ? 'sports-bg-blue text-white' 
                  : 'border-gray-300 text-gray-700 hover:border-blue-500'
              }`}
            >
              التنس
            </Button>
          </div>
        </div>
      </section>

      {/* Results List */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-6">
            {currentResults.map((result, index) => (
              <Card key={result.rank} className="overflow-hidden hover:shadow-xl transition-all duration-300">
                <CardContent className="p-0">
                  <div className="flex flex-col md:flex-row">
                    {/* Rank Section */}
                    <div className={`${getRankBadgeColor(result.rank)} p-8 flex flex-col items-center justify-center min-w-[120px]`}>
                      {getRankIcon(result.rank)}
                      <div className="text-2xl font-bold text-white mt-2">#{result.rank}</div>
                      <div className="text-white opacity-90 text-sm">المركز</div>
                    </div>

                    {/* Image Section */}
                    <div className="w-full md:w-48 h-48 md:h-auto">
                      <img 
                        src={result.image} 
                        alt={result.title}
                        className="w-full h-full object-cover"
                      />
                    </div>

                    {/* Content Section */}
                    <div className="flex-1 p-6">
                      <div className="flex flex-col md:flex-row md:items-start md:justify-between">
                        <div className="flex-1 mb-4 md:mb-0">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant="outline" className="sports-text-blue border-blue-200">
                              {result.sport}
                            </Badge>
                            <Badge variant="secondary">
                              {result.country}
                            </Badge>
                          </div>
                          
                          <h3 className="text-xl font-bold sports-text-dark mb-2 line-clamp-2">
                            {result.title}
                          </h3>
                          
                          <p className="text-gray-600 mb-3">
                            بواسطة: <span className="font-medium">{result.participant}</span>
                          </p>

                          <div className="flex items-center gap-6 text-sm text-gray-500">
                            <span className="flex items-center">
                              <Heart className="w-4 h-4 ml-1 text-red-500" />
                              {result.votes.toLocaleString()} صوت
                            </span>
                            <span className="flex items-center">
                              <Eye className="w-4 h-4 ml-1 text-blue-500" />
                              {result.views.toLocaleString()} مشاهدة
                            </span>
                            <span className="flex items-center text-green-600">
                              <TrendingUp className="w-4 h-4 ml-1" />
                              +{result.trend} اليوم
                            </span>
                          </div>
                        </div>

                        {/* Stats Section */}
                        <div className="text-center md:text-right">
                          <div className="text-3xl font-bold sports-text-dark mb-1">
                            {result.percentage}%
                          </div>
                          <div className="text-sm text-gray-500 mb-4">من إجمالي الأصوات</div>
                          
                          {/* Progress Bar */}
                          <div className="w-full md:w-32 bg-gray-200 rounded-full h-2 mb-4">
                            <div 
                              className="sports-bg-blue h-2 rounded-full transition-all duration-500"
                              style={{ width: `${result.percentage * 5}%` }}
                            ></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {currentResults.length === 0 && (
            <div className="text-center py-20">
              <div className="text-6xl mb-4">🏆</div>
              <h3 className="text-2xl font-bold text-gray-600 mb-2">لا توجد نتائج في هذه الفئة</h3>
              <p className="text-gray-500">جرب فئة أخرى لمشاهدة النتائج</p>
            </div>
          )}
        </div>
      </section>

      {/* Live Updates */}
      <section className="py-20 sports-gradient-gold">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            تحديثات مباشرة
          </h2>
          <p className="text-xl text-white opacity-90 mb-8">
            النتائج تتحدث كل دقيقة! تابع التغييرات في الترتيب والأصوات الجديدة
          </p>
          
          <div className="bg-white bg-opacity-20 rounded-2xl p-8 backdrop-blur-sm">
            <div className="flex items-center justify-center mb-4">
              <div className="w-4 h-4 bg-green-400 rounded-full animate-pulse ml-3"></div>
              <span className="text-white font-medium">مباشر الآن</span>
            </div>
            <p className="text-white opacity-90">
              آخر تحديث: منذ دقيقتين • +47 صوت جديد
            </p>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Results

