import React, { useState } from 'react'
import { Heart, Eye, Share2, MessageCircle, Trophy, Star, Filter, Search } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

const Gallery = () => {
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [searchTerm, setSearchTerm] = useState('')
  const [votedItems, setVotedItems] = useState(new Set())

  // بيانات وهمية للمشاركات
  const submissions = [
    {
      id: 1,
      title: 'جماهير الأهلي في نهائي دوري الأبطال',
      participant: 'أحمد محمد',
      country: 'مصر',
      sport: 'كرة القدم',
      image: '/src/assets/images/fans/fans_1.jpg',
      votes: 1250,
      views: 5420,
      category: 'football',
      description: 'لحظة تاريخية من جماهير النادي الأهلي في نهائي دوري أبطال أفريقيا',
      isVideo: false,
      rank: 1
    },
    {
      id: 2,
      title: 'مشجعو المنتخب السعودي في كأس العالم',
      participant: 'سارة العتيبي',
      country: 'السعودية',
      sport: 'كرة القدم',
      image: '/src/assets/images/fans/fans_2.jpg',
      votes: 980,
      views: 3210,
      category: 'football',
      description: 'احتفال جماهير المنتخب السعودي بالفوز التاريخي في كأس العالم',
      isVideo: true,
      rank: 2
    },
    {
      id: 3,
      title: 'جماهير كرة السلة في الدوري الأمريكي',
      participant: 'محمد الأحمد',
      country: 'الإمارات',
      sport: 'كرة السلة',
      image: '/src/assets/images/sports/sports_1.jpeg',
      votes: 750,
      views: 2890,
      category: 'basketball',
      description: 'أجواء رائعة من جماهير كرة السلة في مباراة حاسمة',
      isVideo: false,
      rank: 3
    },
    {
      id: 4,
      title: 'مشجعو التنس في بطولة ويمبلدون',
      participant: 'فاطمة الزهراء',
      country: 'المغرب',
      sport: 'التنس',
      image: '/src/assets/images/sports/sports_2.jpg',
      votes: 620,
      views: 1950,
      category: 'tennis',
      description: 'لحظات مميزة من جماهير التنس في بطولة ويمبلدون العريقة',
      isVideo: false,
      rank: 4
    }
  ]

  const categories = [
    { id: 'all', name: 'جميع الرياضات', count: submissions.length },
    { id: 'football', name: 'كرة القدم', count: 2 },
    { id: 'basketball', name: 'كرة السلة', count: 1 },
    { id: 'tennis', name: 'التنس', count: 1 }
  ]

  const handleVote = (submissionId) => {
    const newVotedItems = new Set(votedItems)
    if (votedItems.has(submissionId)) {
      newVotedItems.delete(submissionId)
    } else {
      newVotedItems.add(submissionId)
    }
    setVotedItems(newVotedItems)
  }

  const filteredSubmissions = submissions.filter(submission => {
    const matchesCategory = selectedCategory === 'all' || submission.category === selectedCategory
    const matchesSearch = submission.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         submission.participant.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         submission.country.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesCategory && matchesSearch
  })

  const getRankBadgeColor = (rank) => {
    switch(rank) {
      case 1: return 'bg-yellow-500 text-white'
      case 2: return 'bg-gray-400 text-white'
      case 3: return 'bg-amber-600 text-white'
      default: return 'bg-blue-500 text-white'
    }
  }

  return (
    <div className="min-h-screen pt-16 bg-gray-50">
      {/* Header Section */}
      <section className="sports-gradient py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
            معرض المشاركات
          </h1>
          <p className="text-xl text-white opacity-90 mb-8 max-w-3xl mx-auto">
            اكتشف أفضل المشاركات من الجماهير الرياضية حول العالم وصوت لمفضلتك
          </p>
          
          {/* Search Bar */}
          <div className="max-w-2xl mx-auto relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="ابحث عن المشاركات..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-4 rounded-full text-lg border-0 focus:ring-2 focus:ring-white focus:ring-opacity-50"
            />
          </div>
        </div>
      </section>

      {/* Categories Filter */}
      <section className="py-8 bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold sports-text-dark flex items-center">
              <Filter className="w-6 h-6 ml-2" />
              تصفية حسب الرياضة
            </h2>
            <div className="text-gray-600">
              {filteredSubmissions.length} مشاركة
            </div>
          </div>
          
          <div className="flex flex-wrap gap-4">
            {categories.map(category => (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                onClick={() => setSelectedCategory(category.id)}
                className={`rounded-full px-6 py-2 ${
                  selectedCategory === category.id 
                    ? 'sports-bg-blue text-white' 
                    : 'border-gray-300 text-gray-700 hover:border-blue-500'
                }`}
              >
                {category.name}
                <Badge variant="secondary" className="mr-2">
                  {category.count}
                </Badge>
              </Button>
            ))}
          </div>
        </div>
      </section>

      {/* Submissions Grid */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredSubmissions.map(submission => (
              <Card key={submission.id} className="overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
                <div className="relative">
                  <img 
                    src={submission.image} 
                    alt={submission.title}
                    className="w-full h-64 object-cover"
                  />
                  
                  {/* Rank Badge */}
                  <Badge className={`absolute top-4 right-4 ${getRankBadgeColor(submission.rank)} px-3 py-1`}>
                    <Trophy className="w-4 h-4 ml-1" />
                    المركز {submission.rank}
                  </Badge>

                  {/* Video Indicator */}
                  {submission.isVideo && (
                    <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center">
                      <div className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                        <div className="w-0 h-0 border-l-8 border-l-white border-t-4 border-t-transparent border-b-4 border-b-transparent mr-1"></div>
                      </div>
                    </div>
                  )}

                  {/* Country Flag */}
                  <div className="absolute top-4 left-4 bg-white bg-opacity-90 px-3 py-1 rounded-full text-sm font-medium">
                    {submission.country}
                  </div>
                </div>

                <CardContent className="p-6">
                  <div className="mb-4">
                    <Badge variant="outline" className="sports-text-blue border-blue-200 mb-2">
                      {submission.sport}
                    </Badge>
                    <h3 className="text-xl font-bold sports-text-dark mb-2 line-clamp-2">
                      {submission.title}
                    </h3>
                    <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                      {submission.description}
                    </p>
                    <p className="text-sm text-gray-500">
                      بواسطة: <span className="font-medium">{submission.participant}</span>
                    </p>
                  </div>

                  {/* Stats */}
                  <div className="flex items-center justify-between mb-4 text-sm text-gray-500">
                    <div className="flex items-center space-x-4 rtl:space-x-reverse">
                      <span className="flex items-center">
                        <Eye className="w-4 h-4 ml-1" />
                        {submission.views.toLocaleString()}
                      </span>
                      <span className="flex items-center">
                        <Heart className="w-4 h-4 ml-1" />
                        {submission.votes.toLocaleString()}
                      </span>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center justify-between">
                    <Button
                      onClick={() => handleVote(submission.id)}
                      variant={votedItems.has(submission.id) ? "default" : "outline"}
                      className={`flex-1 ml-2 ${
                        votedItems.has(submission.id)
                          ? 'sports-bg-red text-white'
                          : 'border-red-300 text-red-600 hover:bg-red-50'
                      }`}
                    >
                      <Heart className={`w-4 h-4 ml-1 ${votedItems.has(submission.id) ? 'fill-current' : ''}`} />
                      {votedItems.has(submission.id) ? 'تم التصويت' : 'صوت الآن'}
                    </Button>
                    
                    <div className="flex space-x-2 rtl:space-x-reverse">
                      <Button variant="outline" size="sm" className="p-2">
                        <MessageCircle className="w-4 h-4" />
                      </Button>
                      <Button variant="outline" size="sm" className="p-2">
                        <Share2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredSubmissions.length === 0 && (
            <div className="text-center py-20">
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-2xl font-bold text-gray-600 mb-2">لا توجد نتائج</h3>
              <p className="text-gray-500">جرب البحث بكلمات مختلفة أو غير الفئة المحددة</p>
            </div>
          )}
        </div>
      </section>

      {/* Fan Journey CTA */}
      <section className="py-20 sports-gradient-gold">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            رحلة المشجع العادي
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="bg-white bg-opacity-20 rounded-2xl p-6 backdrop-blur-sm">
              <div className="w-12 h-12 bg-white bg-opacity-30 rounded-full flex items-center justify-center mx-auto mb-4">
                <Eye className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">اكتشف</h3>
              <p className="text-white opacity-90 text-sm">تعرف على المسابقة والمشاركات</p>
            </div>
            
            <div className="bg-white bg-opacity-20 rounded-2xl p-6 backdrop-blur-sm">
              <div className="w-12 h-12 bg-white bg-opacity-30 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">صوت</h3>
              <p className="text-white opacity-90 text-sm">اختر مشاركتك المفضلة</p>
            </div>
            
            <div className="bg-white bg-opacity-20 rounded-2xl p-6 backdrop-blur-sm">
              <div className="w-12 h-12 bg-white bg-opacity-30 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trophy className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">تابع</h3>
              <p className="text-white opacity-90 text-sm">راقب النتائج والترتيب</p>
            </div>
            
            <div className="bg-white bg-opacity-20 rounded-2xl p-6 backdrop-blur-sm">
              <div className="w-12 h-12 bg-white bg-opacity-30 rounded-full flex items-center justify-center mx-auto mb-4">
                <Share2 className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">شارك</h3>
              <p className="text-white opacity-90 text-sm">انشر وتفاعل مع الآخرين</p>
            </div>
          </div>
          
          <p className="text-xl text-white opacity-90 mb-8">
            انضم إلى آلاف المشجعين حول العالم في هذه التجربة المميزة
          </p>
        </div>
      </section>
    </div>
  )
}

export default Gallery

