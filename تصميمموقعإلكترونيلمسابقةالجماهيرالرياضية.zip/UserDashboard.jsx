import React, { useState } from 'react'
import { 
  User, 
  Upload, 
  Trophy, 
  Eye, 
  Heart, 
  MessageSquare, 
  Calendar, 
  Award, 
  Settings, 
  Bell,
  Camera,
  Video,
  Edit3,
  Share2,
  Download,
  BarChart3
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'

const UserDashboard = () => {
  const [activeTab, setActiveTab] = useState('overview')

  // Mock user data
  const userData = {
    name: 'أحمد محمد',
    email: 'ahmed@example.com',
    country: 'المملكة العربية السعودية',
    joinDate: '15 نوفمبر 2024',
    avatar: '/src/assets/images/fans/fans_1.jpg',
    totalSubmissions: 5,
    totalVotes: 1250,
    totalViews: 8500,
    rank: 'مشجع ذهبي',
    points: 2850
  }

  const submissions = [
    {
      id: 1,
      title: 'تشجيع الهلال في نهائي آسيا',
      sport: 'كرة القدم',
      type: 'فيديو',
      status: 'مقبول',
      votes: 450,
      views: 2100,
      likes: 89,
      comments: 23,
      uploadDate: '20 نوفمبر 2024',
      thumbnail: '/src/assets/images/sports/sports_1.jpeg'
    },
    {
      id: 2,
      title: 'لوحة فنية للمنتخب السعودي',
      sport: 'كرة القدم',
      type: 'صورة',
      status: 'قيد المراجعة',
      votes: 320,
      views: 1800,
      likes: 67,
      comments: 15,
      uploadDate: '18 نوفمبر 2024',
      thumbnail: '/src/assets/images/fans/fans_2.jpg'
    },
    {
      id: 3,
      title: 'تشجيع فريق السلة المحلي',
      sport: 'كرة السلة',
      type: 'فيديو',
      status: 'مقبول',
      votes: 280,
      views: 1500,
      likes: 45,
      comments: 12,
      uploadDate: '16 نوفمبر 2024',
      thumbnail: '/src/assets/images/sports/sports_2.jpg'
    }
  ]

  const achievements = [
    { title: 'أول مشاركة', description: 'رفعت أول مشاركة لك', icon: Upload, earned: true },
    { title: 'محبوب الجماهير', description: 'حصلت على 100 إعجاب', icon: Heart, earned: true },
    { title: 'نجم المشاهدات', description: 'وصلت إلى 1000 مشاهدة', icon: Eye, earned: true },
    { title: 'مشجع متفاعل', description: 'علقت على 50 مشاركة', icon: MessageSquare, earned: false },
    { title: 'بطل التصويت', description: 'صوتت لـ 100 مشاركة', icon: Trophy, earned: false },
    { title: 'مشجع ماسي', description: 'وصلت إلى 5000 نقطة', icon: Award, earned: false }
  ]

  const getStatusColor = (status) => {
    switch (status) {
      case 'مقبول': return 'bg-green-100 text-green-800'
      case 'قيد المراجعة': return 'bg-yellow-100 text-yellow-800'
      case 'مرفوض': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getTypeIcon = (type) => {
    return type === 'فيديو' ? Video : Camera
  }

  return (
    <div className="min-h-screen bg-gray-50 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
            <div className="flex items-center space-x-6 rtl:space-x-reverse mb-6 md:mb-0">
              <div className="relative">
                <img 
                  src={userData.avatar} 
                  alt={userData.name}
                  className="w-24 h-24 rounded-full object-cover border-4 border-white shadow-lg"
                />
                <div className="absolute -bottom-2 -right-2 w-8 h-8 sports-bg-gold rounded-full flex items-center justify-center">
                  <Trophy className="w-4 h-4 text-white" />
                </div>
              </div>
              
              <div>
                <h1 className="text-3xl font-bold sports-text-dark mb-2">{userData.name}</h1>
                <p className="text-gray-600 mb-1">{userData.email}</p>
                <p className="text-gray-600 mb-2">{userData.country}</p>
                <Badge className="sports-bg-gold text-white">{userData.rank}</Badge>
              </div>
            </div>
            
            <div className="flex space-x-4 rtl:space-x-reverse">
              <Button variant="outline" className="flex items-center">
                <Settings className="w-4 h-4 ml-2" />
                الإعدادات
              </Button>
              <Button variant="outline" className="flex items-center">
                <Bell className="w-4 h-4 ml-2" />
                الإشعارات
              </Button>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 sports-bg-green rounded-full flex items-center justify-center mx-auto mb-4">
                <Upload className="w-6 h-6 text-white" />
              </div>
              <div className="text-2xl font-bold sports-text-dark mb-1">{userData.totalSubmissions}</div>
              <div className="text-gray-600">مشاركات</div>
            </CardContent>
          </Card>
          
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 sports-bg-blue rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <div className="text-2xl font-bold sports-text-dark mb-1">{userData.totalVotes}</div>
              <div className="text-gray-600">إعجاب</div>
            </CardContent>
          </Card>
          
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 sports-bg-gold rounded-full flex items-center justify-center mx-auto mb-4">
                <Eye className="w-6 h-6 text-white" />
              </div>
              <div className="text-2xl font-bold sports-text-dark mb-1">{userData.totalViews}</div>
              <div className="text-gray-600">مشاهدة</div>
            </CardContent>
          </Card>
          
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-6 h-6 text-white" />
              </div>
              <div className="text-2xl font-bold sports-text-dark mb-1">{userData.points}</div>
              <div className="text-gray-600">نقطة</div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:grid-cols-4">
            <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
            <TabsTrigger value="submissions">مشاركاتي</TabsTrigger>
            <TabsTrigger value="achievements">الإنجازات</TabsTrigger>
            <TabsTrigger value="analytics">الإحصائيات</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Recent Activity */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Calendar className="w-5 h-5 ml-2" />
                    النشاط الأخير
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-4 rtl:space-x-reverse">
                      <div className="w-2 h-2 sports-bg-green rounded-full"></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">تم قبول مشاركتك "تشجيع الهلال"</p>
                        <p className="text-xs text-gray-500">منذ ساعتين</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4 rtl:space-x-reverse">
                      <div className="w-2 h-2 sports-bg-blue rounded-full"></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">حصلت على 50 إعجاب جديد</p>
                        <p className="text-xs text-gray-500">منذ 4 ساعات</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4 rtl:space-x-reverse">
                      <div className="w-2 h-2 sports-bg-gold rounded-full"></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">رفعت مشاركة جديدة</p>
                        <p className="text-xs text-gray-500">أمس</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Progress to Next Level */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BarChart3 className="w-5 h-5 ml-2" />
                    التقدم للمستوى التالي
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">مشجع ماسي</span>
                      <span className="text-sm text-gray-500">2850 / 5000</span>
                    </div>
                    <Progress value={57} className="h-3" />
                    <p className="text-sm text-gray-600">
                      تحتاج إلى 2150 نقطة إضافية للوصول للمستوى التالي
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Submissions Tab */}
          <TabsContent value="submissions" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold sports-text-dark">مشاركاتي</h2>
              <Button className="sports-bg-green hover:bg-green-600 text-white">
                <Upload className="w-4 h-4 ml-2" />
                مشاركة جديدة
              </Button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {submissions.map((submission) => {
                const TypeIcon = getTypeIcon(submission.type)
                return (
                  <Card key={submission.id} className="border-0 shadow-lg overflow-hidden">
                    <div className="relative">
                      <img 
                        src={submission.thumbnail} 
                        alt={submission.title}
                        className="w-full h-48 object-cover"
                      />
                      <div className="absolute top-4 right-4">
                        <Badge className={getStatusColor(submission.status)}>
                          {submission.status}
                        </Badge>
                      </div>
                      <div className="absolute bottom-4 left-4">
                        <div className="flex items-center space-x-2 rtl:space-x-reverse">
                          <div className="bg-black bg-opacity-50 rounded-full p-2">
                            <TypeIcon className="w-4 h-4 text-white" />
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <CardContent className="p-6">
                      <h3 className="font-bold sports-text-dark mb-2">{submission.title}</h3>
                      <p className="text-sm text-gray-600 mb-4">{submission.sport}</p>
                      
                      <div className="grid grid-cols-3 gap-4 mb-4">
                        <div className="text-center">
                          <div className="text-lg font-bold sports-text-green">{submission.votes}</div>
                          <div className="text-xs text-gray-500">تصويت</div>
                        </div>
                        <div className="text-center">
                          <div className="text-lg font-bold sports-text-blue">{submission.views}</div>
                          <div className="text-xs text-gray-500">مشاهدة</div>
                        </div>
                        <div className="text-center">
                          <div className="text-lg font-bold sports-text-gold">{submission.likes}</div>
                          <div className="text-xs text-gray-500">إعجاب</div>
                        </div>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <span className="text-xs text-gray-500">{submission.uploadDate}</span>
                        <div className="flex space-x-2 rtl:space-x-reverse">
                          <Button variant="outline" size="sm">
                            <Edit3 className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Share2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </TabsContent>

          {/* Achievements Tab */}
          <TabsContent value="achievements" className="space-y-6">
            <h2 className="text-2xl font-bold sports-text-dark">الإنجازات</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {achievements.map((achievement, index) => {
                const Icon = achievement.icon
                return (
                  <Card 
                    key={index} 
                    className={`border-0 shadow-lg ${achievement.earned ? 'ring-2 ring-green-500' : 'opacity-60'}`}
                  >
                    <CardContent className="p-6 text-center">
                      <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${
                        achievement.earned ? 'sports-bg-gold' : 'bg-gray-300'
                      }`}>
                        <Icon className="w-8 h-8 text-white" />
                      </div>
                      <h3 className="font-bold sports-text-dark mb-2">{achievement.title}</h3>
                      <p className="text-sm text-gray-600">{achievement.description}</p>
                      {achievement.earned && (
                        <Badge className="mt-3 bg-green-100 text-green-800">مكتمل</Badge>
                      )}
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <h2 className="text-2xl font-bold sports-text-dark">الإحصائيات التفصيلية</h2>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>أداء المشاركات</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>متوسط المشاهدات</span>
                      <span className="font-bold">1,700</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>متوسط الإعجابات</span>
                      <span className="font-bold">67</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>معدل التفاعل</span>
                      <span className="font-bold">4.2%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>التوزيع حسب الرياضة</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>كرة القدم</span>
                      <div className="flex items-center space-x-2 rtl:space-x-reverse">
                        <div className="w-20 h-2 bg-gray-200 rounded-full">
                          <div className="w-16 h-2 sports-bg-green rounded-full"></div>
                        </div>
                        <span className="text-sm">80%</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>كرة السلة</span>
                      <div className="flex items-center space-x-2 rtl:space-x-reverse">
                        <div className="w-20 h-2 bg-gray-200 rounded-full">
                          <div className="w-4 h-2 sports-bg-blue rounded-full"></div>
                        </div>
                        <span className="text-sm">20%</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default UserDashboard

