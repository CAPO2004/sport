import React, { useState } from 'react'
import { ChevronDown, ChevronUp, HelpCircle, Search, MessageCircle, Phone, Mail } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

const FAQ = () => {
  const [searchTerm, setSearchTerm] = useState('')
  const [openItems, setOpenItems] = useState({})

  const toggleItem = (index) => {
    setOpenItems(prev => ({
      ...prev,
      [index]: !prev[index]
    }))
  }

  const faqCategories = [
    {
      title: 'عن المسابقة',
      icon: HelpCircle,
      color: 'sports-bg-green',
      questions: [
        {
          question: 'ما هي مسابقة الجماهير الرياضية العالمية؟',
          answer: 'مسابقة عالمية تهدف إلى تكريم الجماهير الرياضية وإبراز دورهم المهم في دعم الرياضة والرياضيين. نحتفي بالشغف والحماس والولاء الذي يظهره المشجعون في جميع أنحاء العالم.'
        },
        {
          question: 'من يمكنه المشاركة في المسابقة؟',
          answer: 'يمكن لأي شخص من أي دولة في العالم المشاركة في المسابقة، بشرط أن يكون عمره 16 سنة أو أكثر. المسابقة مفتوحة لجميع محبي الرياضة والمشجعين.'
        },
        {
          question: 'ما هي الرياضات المشمولة في المسابقة؟',
          answer: 'تشمل المسابقة أكثر من 15 رياضة مختلفة منها: كرة القدم، كرة السلة، الكرة الطائرة، ألعاب القوى، السباحة، الرياضات الإلكترونية، وغيرها من الرياضات الشعبية.'
        },
        {
          question: 'متى تنتهي فترة التسجيل؟',
          answer: 'تنتهي فترة التسجيل في 31 ديسمبر 2024. ننصح بالتسجيل مبكراً لضمان قبول المشاركة.'
        }
      ]
    },
    {
      title: 'التسجيل والمشاركة',
      icon: MessageCircle,
      color: 'sports-bg-blue',
      questions: [
        {
          question: 'كيف يمكنني التسجيل في المسابقة؟',
          answer: 'يمكنك التسجيل من خلال ملء نموذج التسجيل في صفحة "كيف تشارك" ورفع صورك أو فيديوهاتك التي تظهر شغفك الرياضي.'
        },
        {
          question: 'ما نوع المحتوى المطلوب للمشاركة؟',
          answer: 'يمكنك رفع صور أو فيديوهات تظهر تشجيعك للفرق أو الرياضيين، أو إبداعاتك في دعم الرياضة. يجب أن يكون المحتوى أصلياً ومن تصويرك.'
        },
        {
          question: 'هل يمكنني المشاركة في أكثر من رياضة؟',
          answer: 'نعم، يمكنك المشاركة في عدة رياضات مختلفة، لكن كل مشاركة يجب أن تكون منفصلة ومخصصة لرياضة واحدة.'
        },
        {
          question: 'ما هي شروط المحتوى المرفوع؟',
          answer: 'يجب أن يكون المحتوى أصلياً، لائقاً، غير مخالف للقوانين، ويظهر الشغف الرياضي بطريقة إيجابية. حجم الملف يجب ألا يتجاوز 50 ميجابايت.'
        }
      ]
    },
    {
      title: 'التصويت والتقييم',
      icon: Phone,
      color: 'sports-bg-gold',
      questions: [
        {
          question: 'كيف يتم تقييم المشاركات؟',
          answer: 'يتم التقييم من خلال مزيج من التصويت الجماهيري (50%) وتقييم لجنة متخصصة (50%). اللجنة تضم خبراء في الرياضة والإعلام.'
        },
        {
          question: 'متى يمكنني التصويت؟',
          answer: 'يبدأ التصويت الجماهيري في 15 يناير 2025 وينتهي في 28 فبراير 2025. ستتمكن من التصويت لمشاركة واحدة في كل فئة رياضية.'
        },
        {
          question: 'هل يمكنني التصويت لنفسي؟',
          answer: 'لا، لا يمكن للمشاركين التصويت لمشاركاتهم الخاصة. يمكنك فقط التصويت للمشاركات الأخرى.'
        },
        {
          question: 'كيف أضمن عدالة التصويت؟',
          answer: 'نستخدم نظام تحقق متقدم يتطلب رقم هاتف أو بريد إلكتروني للتصويت، مع منع التصويت المتكرر من نفس الجهاز.'
        }
      ]
    },
    {
      title: 'الجوائز والنتائج',
      icon: Mail,
      color: 'bg-purple-500',
      questions: [
        {
          question: 'ما هي قيمة الجوائز؟',
          answer: 'إجمالي قيمة الجوائز يتجاوز 500,000 ريال سعودي، موزعة على الفائزين في جميع الفئات الرياضية.'
        },
        {
          question: 'متى سيتم إعلان النتائج؟',
          answer: 'سيتم إعلان النتائج في حفل التكريم الكبير في 31 ديسمبر 2024، وسيتم التواصل مع الفائزين مسبقاً.'
        },
        {
          question: 'كيف سأستلم الجائزة؟',
          answer: 'سيتم التواصل مع الفائزين عبر البريد الإلكتروني والهاتف لترتيب استلام الجوائز أو تحويلها حسب طبيعة الجائزة.'
        },
        {
          question: 'هل هناك جوائز للمراكز الأخرى؟',
          answer: 'نعم، هناك جوائز للمراكز الثلاثة الأولى في كل فئة رياضية، بالإضافة إلى جوائز تقديرية وشهادات مشاركة.'
        }
      ]
    }
  ]

  const filteredFAQs = faqCategories.map(category => ({
    ...category,
    questions: category.questions.filter(
      q => q.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
           q.answer.toLowerCase().includes(searchTerm.toLowerCase())
    )
  })).filter(category => category.questions.length > 0)

  return (
    <div className="min-h-screen bg-gray-50 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-6 py-3 bg-white rounded-full shadow-lg mb-6">
            <HelpCircle className="w-6 h-6 sports-text-green mr-3" />
            <span className="font-semibold sports-text-dark">الأسئلة الشائعة</span>
          </div>
          
          <h1 className="text-4xl md:text-5xl font-bold sports-text-dark mb-6 section-title">
            الأسئلة الشائعة
          </h1>
          
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            إجابات شاملة على جميع استفساراتك حول مسابقة الجماهير الرياضية العالمية
          </p>
        </div>

        {/* Search Bar */}
        <div className="max-w-2xl mx-auto mb-12">
          <div className="relative">
            <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              type="text"
              placeholder="ابحث في الأسئلة الشائعة..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pr-12 py-4 text-lg rounded-full border-2 border-gray-200 focus:border-green-500"
            />
          </div>
        </div>

        {/* FAQ Categories */}
        <div className="space-y-8">
          {filteredFAQs.map((category, categoryIndex) => {
            const Icon = category.icon
            return (
              <Card key={categoryIndex} className="border-0 shadow-lg overflow-hidden">
                <div className={`${category.color} p-6`}>
                  <div className="flex items-center text-white">
                    <Icon className="w-8 h-8 mr-4" />
                    <h2 className="text-2xl font-bold">{category.title}</h2>
                  </div>
                </div>
                
                <CardContent className="p-0">
                  {category.questions.map((faq, index) => {
                    const itemKey = `${categoryIndex}-${index}`
                    const isOpen = openItems[itemKey]
                    
                    return (
                      <div key={index} className="border-b border-gray-200 last:border-b-0">
                        <button
                          onClick={() => toggleItem(itemKey)}
                          className="w-full p-6 text-right hover:bg-gray-50 transition-colors duration-200 flex items-center justify-between"
                        >
                          <div className="flex items-center">
                            {isOpen ? (
                              <ChevronUp className="w-5 h-5 sports-text-green ml-3" />
                            ) : (
                              <ChevronDown className="w-5 h-5 text-gray-400 ml-3" />
                            )}
                          </div>
                          <h3 className="text-lg font-semibold sports-text-dark text-right flex-1">
                            {faq.question}
                          </h3>
                        </button>
                        
                        {isOpen && (
                          <div className="px-6 pb-6 pt-0">
                            <div className="bg-gray-50 rounded-lg p-6">
                              <p className="text-gray-700 leading-relaxed text-lg">
                                {faq.answer}
                              </p>
                            </div>
                          </div>
                        )}
                      </div>
                    )
                  })}
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Contact Support */}
        <div className="mt-16">
          <Card className="border-0 shadow-2xl overflow-hidden">
            <div className="sports-gradient p-12 text-center">
              <h2 className="text-3xl font-bold text-white mb-4">
                لم تجد إجابة لسؤالك؟
              </h2>
              <p className="text-xl text-white opacity-90 mb-8">
                فريق الدعم جاهز لمساعدتك في أي وقت
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  className="bg-white text-black hover:bg-gray-100 px-8 py-3 rounded-full text-lg font-bold"
                >
                  <Mail className="w-5 h-5 ml-2" />
                  راسلنا عبر البريد
                </Button>
                <Button 
                  variant="outline" 
                  className="border-white text-white hover:bg-white hover:text-black px-8 py-3 rounded-full text-lg"
                >
                  <Phone className="w-5 h-5 ml-2" />
                  اتصل بنا
                </Button>
              </div>
            </div>
          </Card>
        </div>

        {/* Quick Stats */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="w-16 h-16 sports-bg-green rounded-full flex items-center justify-center mx-auto mb-4">
              <HelpCircle className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold sports-text-dark mb-2">24/7</h3>
            <p className="text-gray-600">دعم متواصل</p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 sports-bg-blue rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageCircle className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold sports-text-dark mb-2">{"< 24h"}</h3>
            <p className="text-gray-600">وقت الاستجابة</p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 sports-bg-gold rounded-full flex items-center justify-center mx-auto mb-4">
              <Phone className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold sports-text-dark mb-2">50+</h3>
            <p className="text-gray-600">لغة مدعومة</p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default FAQ

