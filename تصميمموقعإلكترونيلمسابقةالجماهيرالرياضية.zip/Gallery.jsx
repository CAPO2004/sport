import React, { useState } from 'react'
import { Search, Filter, Image, Video, Heart, Eye, MessageSquare } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'

const Gallery = () => {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedSport, setSelectedSport] = useState('all')
  const [selectedCountry, setSelectedCountry] = useState('all')

  const mediaItems = [
    {
      id: 1,
      type: 'image',
      src: '/assets/images/fans/fans_1.jpg',
      alt: 'مشجع كرة قدم',
      sport: 'كرة القدم',
      country: 'السعودية',
      title: 'شغف المدرجات',
      description: 'صورة لمشجع متحمس في مباراة كرة قدم.',
      views: 1200,
      likes: 250,
      comments: 30
    },
    {
      id: 2,
      type: 'video',
      src: '/src/assets/images/sports/sports_1.jpeg',
      alt: 'فيديو تشجيع كرة سلة',
      sport: 'كرة السلة',
      country: 'أمريكا',
      title: 'حماس كرة السلة',
      description: 'فيديو قصير يظهر حماس الجماهير في مباراة كرة سلة.',
      views: 2500,
      likes: 500,
      comments: 75
    },
    {
      id: 3,
      type: 'image',
      src: '/src/assets/images/fans/fans_2.jpg',
      alt: 'مشجعة كرة طائرة',
      sport: 'الكرة الطائرة',
      country: 'البرازيل',
      title: 'فرحة الفوز',
      description: 'مشجعة تحتفل بفوز فريقها في الكرة الطائرة.',
      views: 800,
      likes: 150,
      comments: 20
    },
    {
      id: 4,
      type: 'image',
      src: '/src/assets/images/sports/sports_2.jpg',
      alt: 'مشجع ألعاب قوى',
      sport: 'ألعاب القوى',
      country: 'ألمانيا',
      title: 'قوة الأداء',
      description: 'صورة لمشجع يدعم رياضيي ألعاب القوى.',
      views: 950,
      likes: 180,
      comments: 25
    },
    {
      id: 5,
      type: 'video',
      src: '/src/assets/images/sports/sports_3.jpeg',
      alt: 'فيديو تشجيع سباحة',
      sport: 'السباحة',
      country: 'أستراليا',
      title: 'دعم الأبطال',
      description: 'فيديو يظهر دعم الجماهير لسباحيهم المفضلين.',
      views: 1800,
      likes: 350,
      comments: 40
    },
    {
      id: 6,
      type: 'image',
      src: '/src/assets/images/fans/fans_3.jpg',
      alt: 'مشجع رياضة إلكترونية',
      sport: 'الرياضات الإلكترونية',
      country: 'كوريا الجنوبية',
      title: 'تركيز وتحدي',
      description: 'مشجع يتابع بحماس مباراة رياضة إلكترونية.',
      views: 1500,
      likes: 300,
      comments: 50
    }
  ]

  const filteredMedia = mediaItems.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          item.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesSport = selectedSport === 'all' || item.sport === selectedSport
    const matchesCountry = selectedCountry === 'all' || item.country === selectedCountry
    return matchesSearch && matchesSport && matchesCountry
  })

  const sportsOptions = [...new Set(mediaItems.map(item => item.sport))]
  const countryOptions = [...new Set(mediaItems.map(item => item.country))]

  return (
    <div className="min-h-screen bg-gray-50 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-6 py-3 bg-white rounded-full shadow-lg mb-6">
            <Image className="w-6 h-6 sports-text-green mr-3" />
            <span className="font-semibold sports-text-dark">معرض الصور والفيديو</span>
          </div>
          
          <h1 className="text-4xl md:text-5xl font-bold sports-text-dark mb-6 section-title">
            معرض الصور والفيديو
          </h1>
          
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            شاهد شغف الجماهير من حول العالم في صور ومقاطع فيديو حصرية
          </p>
        </div>

        {/* Filters and Search */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12">
          <div className="relative">
            <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              type="text"
              placeholder="ابحث عن مشاركات..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pr-12 py-3 rounded-full border-2 border-gray-200 focus:border-green-500"
            />
          </div>
          <Select onValueChange={setSelectedSport} value={selectedSport}>
            <SelectTrigger className="rounded-full border-2 border-gray-200 focus:border-green-500">
              <Filter className="w-5 h-5 text-gray-400 ml-2" />
              <SelectValue placeholder="اختر الرياضة" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع الرياضات</SelectItem>
              {sportsOptions.map(sport => (
                <SelectItem key={sport} value={sport}>{sport}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select onValueChange={setSelectedCountry} value={selectedCountry}>
            <SelectTrigger className="rounded-full border-2 border-gray-200 focus:border-green-500">
              <Filter className="w-5 h-5 text-gray-400 ml-2" />
              <SelectValue placeholder="اختر الدولة" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع الدول</SelectItem>
              {countryOptions.map(country => (
                <SelectItem key={country} value={country}>{country}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Media Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredMedia.length > 0 ? (
            filteredMedia.map(item => (
              <Card key={item.id} className="border-0 shadow-lg overflow-hidden group">
                <div className="relative w-full h-60 overflow-hidden">
                  {item.type === 'image' ? (
                    <img 
                      src={item.src} 
                      alt={item.alt}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                  ) : (
                    <video 
                      src={item.src} 
                      poster={item.src} // Use image as poster for video
                      controls={false} 
                      muted 
                      loop 
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                  )}
                  <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <Button className="sports-bg-green hover:bg-green-600 text-white px-6 py-3 rounded-full">
                      {item.type === 'image' ? 'عرض الصورة' : 'مشاهدة الفيديو'}
                    </Button>
                  </div>
                  <div className="absolute top-3 right-3">
                    <Badge className="bg-white text-gray-800 px-3 py-1 rounded-full text-xs font-semibold flex items-center">
                      {item.type === 'image' ? <Image className="w-3 h-3 ml-1" /> : <Video className="w-3 h-3 ml-1" />}
                      {item.type === 'image' ? 'صورة' : 'فيديو'}
                    </Badge>
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold sports-text-dark mb-2">{item.title}</h3>
                  <p className="text-gray-600 text-sm mb-3">{item.description}</p>
                  <div className="flex justify-between items-center text-gray-500 text-sm">
                    <span className="flex items-center"><Eye className="w-4 h-4 ml-1" /> {item.views}</span>
                    <span className="flex items-center"><Heart className="w-4 h-4 ml-1" /> {item.likes}</span>
                    <span className="flex items-center"><MessageSquare className="w-4 h-4 ml-1" /> {item.comments}</span>
                  </div>
                  <div className="flex justify-between items-center mt-4">
                    <Badge className="sports-bg-blue text-white">{item.sport}</Badge>
                    <Badge className="sports-bg-gold text-white">{item.country}</Badge>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="col-span-full text-center py-10">
              <p className="text-gray-600 text-lg">لا توجد مشاركات مطابقة لمعايير البحث.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default Gallery


