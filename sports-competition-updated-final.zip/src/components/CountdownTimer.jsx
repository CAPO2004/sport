import React, { useState, useEffect } from 'react'
import { Clock, Calendar, Trophy } from 'lucide-react'

const CountdownTimer = ({ targetDate = '2024-12-31T23:59:59' }) => {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  })

  useEffect(() => {
    const calculateTimeLeft = () => {
      const difference = +new Date(targetDate) - +new Date()
      
      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60)
        })
      } else {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 })
      }
    }

    calculateTimeLeft()
    const timer = setInterval(calculateTimeLeft, 1000)

    return () => clearInterval(timer)
  }, [targetDate])

  const timeUnits = [
    { label: 'يوم', value: timeLeft.days, color: 'sports-bg-green' },
    { label: 'ساعة', value: timeLeft.hours, color: 'sports-bg-blue' },
    { label: 'دقيقة', value: timeLeft.minutes, color: 'sports-bg-gold' },
    { label: 'ثانية', value: timeLeft.seconds, color: 'bg-red-500' }
  ]

  return (
    <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center mb-4">
          <Trophy className="w-8 h-8 sports-text-gold mr-3" />
          <h3 className="text-2xl font-bold sports-text-dark">حفل التكريم</h3>
        </div>
        <p className="text-gray-600 text-lg">الوقت المتبقي لإعلان النتائج</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {timeUnits.map((unit, index) => (
          <div key={index} className="text-center">
            <div className={`${unit.color} rounded-2xl p-6 mb-3 shadow-lg`}>
              <div className="text-4xl md:text-5xl font-bold text-white">
                {unit.value.toString().padStart(2, '0')}
              </div>
            </div>
            <div className="text-lg font-semibold sports-text-dark">{unit.label}</div>
          </div>
        ))}
      </div>

      <div className="text-center mt-8">
        <div className="flex items-center justify-center text-gray-500 mb-2">
          <Calendar className="w-5 h-5 mr-2" />
          <span>31 ديسمبر 2024</span>
        </div>
        <p className="text-sm text-gray-500">
          سيتم الإعلان عن الفائزين في حفل التكريم الكبير
        </p>
      </div>
    </div>
  )
}

export default CountdownTimer

