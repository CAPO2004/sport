import React from 'react'
import { Link } from 'react-router-dom'
import { Trophy, Facebook, Twitter, Instagram, Youtube, Mail, Phone, MapPin } from 'lucide-react'

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo and Description */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-2 rtl:space-x-reverse mb-4">
              <div className="w-10 h-10 sports-gradient rounded-full flex items-center justify-center">
                <Trophy className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold">مسابقة الجماهير</span>
            </div>
            <p className="text-gray-300 leading-relaxed mb-4">
              مسابقة عالمية تحتفي بالجماهير الرياضية وتكرم شغفهم وحماسهم في دعم الرياضة والرياضيين حول العالم.
            </p>
            <div className="flex space-x-4 rtl:space-x-reverse">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Youtube className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">روابط سريعة</h3>
            <ul className="space-y-2">
              <li><Link to="/" className="text-gray-300 hover:text-white transition-colors">الرئيسية</Link></li>
              <li><Link to="/about" className="text-gray-300 hover:text-white transition-colors">عن المسابقة</Link></li>
              <li><Link to="/participate" className="text-gray-300 hover:text-white transition-colors">كيف تشارك</Link></li>
              <li><Link to="/awards" className="text-gray-300 hover:text-white transition-colors">الجوائز</Link></li>
              <li><Link to="/voting" className="text-gray-300 hover:text-white transition-colors">التصويت</Link></li>
            </ul>
          </div>

          {/* Sports Categories */}
          <div>
            <h3 className="text-lg font-semibold mb-4">الرياضات</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">كرة القدم</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">كرة السلة</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">الكرة الطائرة</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">السباحة</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">ألعاب القوى</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4">تواصل معنا</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3 rtl:space-x-reverse">
                <Mail className="w-5 h-5 text-gray-400" />
                <span className="text-gray-300">info@sportsfans.com</span>
              </div>
              <div className="flex items-center space-x-3 rtl:space-x-reverse">
                <Phone className="w-5 h-5 text-gray-400" />
                <span className="text-gray-300">+966 11 123 4567</span>
              </div>
              <div className="flex items-center space-x-3 rtl:space-x-reverse">
                <MapPin className="w-5 h-5 text-gray-400" />
                <span className="text-gray-300">الرياض، المملكة العربية السعودية</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-gray-400 text-sm mb-4 md:mb-0">
              © 2024 مسابقة الجماهير الرياضية. جميع الحقوق محفوظة.
            </div>
            <div className="flex space-x-6 rtl:space-x-reverse text-sm">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">سياسة الخصوصية</a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">الشروط والأحكام</a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">اتفاقية الاستخدام</a>
            </div>
          </div>
        </div>

        {/* Sponsor Section */}
        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className="text-gray-400 mb-4">برعاية</p>
          <div className="flex justify-center">
            <img 
              src="/src/assets/images/sponsor/sponsor_logo.png" 
              alt="الراعي الرسمي" 
              className="h-12 opacity-70 hover:opacity-100 transition-opacity"
            />
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer

